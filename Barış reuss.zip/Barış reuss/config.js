module.exports = {
    token: "", 
    prefix: "!"
}

